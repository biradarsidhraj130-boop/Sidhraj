
SELECT Attrition, COUNT(*) AS Total
FROM hr_full_data
GROUP BY Attrition;

-- Attrition by department
SELECT Department, COUNT(*) AS Attrition_Count
FROM hr_full_data
WHERE Attrition = 'Yes'
GROUP BY Department
ORDER BY Attrition_Count DESC;

-- Attrition by job role
SELECT JobRole, COUNT(*) AS Attrition_Count
FROM hr_full_data
WHERE Attrition = 'Yes'
GROUP BY JobRole
ORDER BY Attrition_Count DESC;

-- Attrition by age group
SELECT 
CASE 
    WHEN Age BETWEEN 20 AND 30 THEN '20-30'
    WHEN Age BETWEEN 31 AND 40 THEN '31-40'
    WHEN Age BETWEEN 41 AND 50 THEN '41-50'
    ELSE '50+'
END AS Age_Group,
COUNT(*) AS Attrition_Count
FROM hr_full_data
WHERE Attrition = 'Yes'
GROUP BY Age_Group
ORDER BY Attrition_Count DESC;