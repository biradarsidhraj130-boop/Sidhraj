# Employee Attrition Analysis

## Project Overview

This project analyzes employee attrition trends using SQL, Python, and Power BI to identify key factors affecting employee turnover and provide actionable business insights.

## Tools & Technologies

* MySQL (Data Analysis)
* Python (Pandas, Matplotlib, Seaborn)
* Power BI (Dashboard Visualization)

##  Key Insights

* Highest attrition observed in Sales and Research & Development departments
* Employees aged 20–30 show higher attrition trends
* Lower salary employees are more likely to leave
* Job roles such as Sales Executive and Laboratory Technician have higher turnover

## Recommendations

* Improve retention strategies in high-attrition departments
* Provide better compensation for lower salary groups
* Focus on employee engagement and career growth programs
* Implement targeted retention strategies for younger employees

## Project Files

* `employee_attrition_analysis.sql` → SQL queries
* `hr_attrition_analysis.ipynb` → Python analysis
* `.pbix` file → Power BI dashboard
* PDF reports → Final outputs

## Outcome

This project demonstrates end-to-end data analysis skills including data cleaning, SQL querying, data visualization, and business insight generation.
